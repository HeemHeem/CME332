#define LEFT	0
#define RIGHT	1

#define OFF	0
#define ON	1
